function mostraMensagem(){
    const nome = "Lira";
    console.log(`Olá ${nome}! Seja bem vindo`) 

    return nome;
};

let nome = mostraMensagem();