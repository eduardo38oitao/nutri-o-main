var a = 5;
var b = 8;
var soma = a + b;

var c = 98;
var somaTotal = a + b + c;

if(soma <= 12 || soma >= 14){
    alert("Soma Inválida!");
};

console.log(soma);
console.log(somaTotal);
